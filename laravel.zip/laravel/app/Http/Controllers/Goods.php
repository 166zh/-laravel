<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Goods extends Controller
{
    public function show(){
    	echo '123123';
    }
}
