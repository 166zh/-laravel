<?php

namespace App\Http\Controllers\order;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Shool;
use App\Model\Shoolss;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cookie;


class Goods extends Controller
{
    public function show(){
    	$arr = Shoolss::all();
    	return view('zhang.zhang') -> with(['arr'=>$arr]);
    	
    }
    public function inser(Request $request){
    	$post=$request->input();
    	$arr=Db::table('shool')->insertGetId($post);
    	return $arr;
    }
    public function is(){
    	$sql = DB::table('shool')
    		->join('shoolss','shool.b_id','=','shoolss.b_id')
    		->where('state',0)
    		->paginate(3);
    	return view('zhang.list') -> with(['sql'=>$sql]);
    }
    public function delet(Request $request){
    	$id=$request->input();
    	$sql =  DB::table('shool')->where("a_id",$id)->update(['state'=>1]);
    	if($sql){
    		return 1;
    	}
    }


    //修改
  public function etix($id){
    	$goodsdata = Shool::where('a_id',$id)->get();
    	$categorydata = Shoolss::all();
    	return view('zhang.update_list') -> with(['goodsdata'=>$goodsdata,'categorydata'=>$categorydata]);
    }
    public function update(Request $request){
    	$post = $request->input();
    	$res = Shool::where('a_id',$post['a_id'])->update($post);
    	if($res){
    		return 1;
    	}else{
    		return 0;
    	}
    }

    public function test(){

    //存 Cookie
    	Cookie::queue("naem","zhngsan");
    	//$name=cookie("naem");
    	//echo $name;
    	
    	
   	//查询Cookie内容
    	$name=Cookie::get("naem");
    	echo $name;
    }

    //即点击该
    public function upName(Request $request){
    	$post=$request->input();
    	$sql=DB::table('shool')->where("a_id",$post['id'])->update(['a_name'=>$post['a_name']]);
    	
        if($sql){
            return [
                'success' => true,
                'msg' => '修改成功'
            ];
        }else{
            return [
                'success' => false,
                'msg' => '修改失败'
            ];
        }
    }
	public function tion(Request $request){
		$post = $request->input();
		$where=[
			'a_hot'=>$post['hot'],
			'a_show'=>$post['show']
		];
		$arr=DB::table('shool')
			->join('shoolss','shool.b_id','=','shoolss.b_id')
			->where('state',0)
			->where($where)
			->paginate(2);
		//print_r($arr);
	return view('zhang.ajax')->with(['arr'=>$arr]);
	}

	

}
