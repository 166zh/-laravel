<?php

namespace App\Http\Controllers\auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Model\Admin;
use App\Model\Goods;
use App\Model\Openss;

class LianxiController extends Controller
{
    public function info(){
        $id=100;
        session(['id'=>$id,'name'=>'zhangsan']);
    }
    public function go(){
        echo 11111;
    }
    //验证码


    public function opens(Request $request){
        $tel=$request->input('tel');


        $num=rand(1000,9999);
        $obj = new \send();
        $a=$obj->show($tel,$num);

        if($a==100){
            $data=[
                'b_tel'=>$tel,
                'b_tell'=>$num,
                'satic'=>1,
                'optime'=>time()+120,
            ];
            $arr=Openss::insert($data);
            if($arr){
                $arr=array(
                    'status'=>1,
                );
                return $arr;
            }
        }

    }
    //登录
    public function login(){
        return view('denglu.login');
    }
    public function login_add(Request $request){
        $post=$request->input();
        $admin_name=$post['name'];
        $admin_pwd=md5($post['pwd']);
        $where=[
            'admin_name'=>$admin_name,
            'admin_pwd'=> $admin_pwd,
        ];
        $zh=Admin::where($where)->first();
        //print_r($zh);die;

        if($zh){
            $admin_id=$zh->admin_id;
            $admin_name=$zh->admin_name;
            $admin_pwd=$zh->admin_pwd;
            session(['uid'=>$admin_id,'name'=>$admin_name]);
            $zh=array(
                'status'=>0,
                'msg'=>'登陆成功'
            );
            return $zh;
        }else{
            $hz=array(
                'status'=>1,
                "msg"=>'账号密码错误'
            );
            return $hz;
        }
    }

    public function index(){
        $tell=Goods::where('is_tell',1)->get();

        $arrs=Goods::get();
        return view('denglu.index')->with(['tell'=>$tell])->with(['arrs'=>$arrs]);
    }
//流加载           首页
    public function goodslist(Request $request){
        $arr = array();
        $page = $request->input('page',1);
        $pageNum=3;
        $offset=($page-1)*$pageNum;

        $arrDaataInfo=DB::table('goods')->offset($offset)->limit($page,$pageNum)->get();
        $totalData=DB::table('goods')->count();
        //总条数
        $pageTotal=ceil($totalData/$pageNum);
        $objview=view('denglu.indexss',['arrDaataInfo'=>$arrDaataInfo]);
        $content=response($objview)->getContent();
        $arr['info']=$content;
        $arr['page']=$pageTotal;
        return $arr;
    }

    //注册
    public function register(Request $request){
        return view('denglu.register');
    }


    public function add(Request $request){
        $post=$request->input();
        $admin_name=$post['admin_name'];
        $pwd=$post['pwd'];
        $conpwd=$post['conpwd'];
        $b_tel=$post['b_tel'];

        $where=[
            'b_tell'=>$b_tel
        ];
        $time=time();
        $zhh=Openss::where($where)->where('optime',">",$time)->first();
        if(!$zhh){
            $zhh=array(
                'status'=>0,
                'msg'=>'验证码错误',
            );
            return $zhh;

        }


        //验证唯一
        $admin=Admin::where('admin_name',$admin_name)->first();
        if(!empty($admin)){
            $admin=array(
                'status'=>0,
                "msg"=>'用户已存在',
            );
            return $admin;
        }
        //入库
        $data=[
            'admin_name'=>$post['admin_name'],
            'admin_pwd'=>md5($post['pwd']),
            'admin_pwds'=>md5($post['conpwd']),
        ];
        $as=Admin::insert($data);
        if($as){
            $as=array(
                'status'=>1,
                "msg"=>'注册成功'
            );
            return $as;
        }

    }
    public  function stode(){
        return view('denglu.stode');
    }

}
