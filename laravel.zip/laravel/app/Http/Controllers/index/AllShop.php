<?php

namespace App\Http\Controllers\index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Model\Category;
use App\Model\Goods;
use App\Model\Carts;
use App\Model\Order;
use App\Model\Detail;

class AllShop extends Controller
{

    //全部商品页面
    public function allshop(){
        $arr=Category::where("parent_id",0)->get();
        $data=Goods::get();

        return view('denglu.allshop')->with(['arr'=>$arr])->with(['data'=>$data]);
    }
    //我的潮购页面

    public function userpage(){
        return view('index.userpage');
    }

  //商品详情页

    public function shopcart(Request $request){
        $goods_id=$request->input('goods_id');

        $sess=$request->session()->get('uid');
        //var_dump($sess);die;
        if(empty($sess)){
            $a=array(
                'status'=>0,
                "msg"=>"请先登录",
            );
            return $a;
        }

        $arr=Goods::where('goods_id',$goods_id)->first();
        if($arr['goods_number']==0){
            $a=array(
                'status'=>1,
                "msg"=>'库存不足'
            );
            return $a;
        }
        //var_dump($arr);die;


        $data=[
            'admin_id'=>$sess,
            'goods_id'=>$arr['goods_id'],
            'goods_name'=>$arr['goods_name'],
            'update_time'=>time(),
            'num'=>1,
        ];

        $where=[
            'goods_id'=>$goods_id,
        ];
        $a=DB::table('carts')->where($where)->first();
        //var_dump($a);die;



        if($a){
            $num=$a->num+1;
            $where=[
                'cart_id'=>$a->cart_id,
            ];
            $array=DB::table('carts')->where($where)->update(['num'=>$num]);

            //var_dump($array);die;
        }else{

            $ar=DB::table('carts')->first();
            $zhang=DB::table('carts')->insert($data);

            if($zhang){
                $zz=array(
                    "status"=>2
                );
                return $zz;
            }

        }


//        if($array){
//            $zh=array(
//                'status'=>2
//            );
//            return $zh;
//        }



    }
    //购物车  订单 页面
    public function payment(Request $request)
    {
        $goodsids = $request->input("data");
        if($goodsids==''){
            $a=array(
                'status'=>2,
                '未选中商品'
            );
            return $a;
        }
        //var_dump($goodsids);
        //购买数量
        $buy_num = $request->input("input");
        //var_dump($buy_num);die;
        //图片路径
        $img = $request->input("img");
        //名称
        $goods_name = $request->input("goods_name");
       // var_dump($goods_name);die;
        $sess = $request->session()->get('uid');
         //var_dump($sess);die;
        if (!$sess) {
            $msg = array(
                "status" => 1,
                "msg" => "没有登录",
            );
            return $msg;
        }

        // DB::table("goods")->where('goods_number',">",0)->whereIn("goods_id",$goodsids);
        $strIds = implode(",", $goodsids);
        $sql = "select goods_id from goods where goods_number > 0 and goods_id in ($strIds)";
        $res = DB::select($sql);
        //var_dump($res);die;
        if (empty($res)) {
            $msg = array(
                'status' => 0,
                "msg" => "库存没有",
            );
            return $msg;
        }
     //入库生产订单  订单表
        //生成 订单的 唯一货号
        $order_name = date("YmdHis", time()) . rand(1000, 9999);
        //总金额

        $tota=0;
        foreach ($goodsids as $values) {

            $pri = DB::table('carts')
                ->join('goods', 'carts.goods_id', '=', 'goods.goods_id')
                ->where('carts.goods_id', $values)
                ->first();
            $price=$pri->num * $pri->shop_price;
            $tota += $price;
    }
        $time=time();
        $datas=array(
            'order_name'=>$order_name,
            'admin_id'=>$sess,
            'order_amount'=>$tota,
            'order_pay_type'=>1,
            'pay_status'=>1,
            'pay_way'=>2,
            'status'=>1,
            'ctime'=>$time,
        );
        $arss=Order::insert($datas);


        //
        if($arss){
            $order=DB::table('order')->where('order_name',$order_name)->first();
            $order_id=$order->order_id;
            //print_r($order_id);die;
            $data=DB::table('carts')
                ->join('goods', 'carts.goods_id', '=', 'goods.goods_id')
                ->whereIn('carts.goods_id',$goodsids)
                ->get();
            //var_dump($data);die;

            foreach($data as $k=>$v){
                $num=$v->num;
                $shop_price=$v->shop_price;
                $goods_name=$v->goods_name;
                $goods_img="uploads/".$v->goods_img;
                //print_r($goods_img);die;
                $Info=[
                    'order_id'=>$order_id,
                    'order_name'=>$order_name,
                    'admin_id'=>$sess,
                    'goods_id'=>$v->goods_id,
                    'buy_number'=>$num,
                    'goods_price'=>$shop_price,
                    'goods_name'=>$goods_name,
                    'goods_image'=>$goods_img,
                    'comment_status'=>1,
                    'status'=>1,
                    'ctime'=>$time
                ];

                $deil=DB::table('detail')->insert($Info);

            }
        }
            if($deil){
                $data=[
                    'is_show'=>1
                ];
                $prss=DB::table('carts')->whereIn('goods_id',$goodsids)->update($data);
                //var_dump($prss);die;
            }
        session(['order_id'=>$order_id,'order_name'=>1]);
        if($deil){
            $deil=array(
                'status'=>3,
                'order_id'=>$order_id
            );
            return $deil;
        }



    }
            //订单页面
            public function pay(Request $request){
                $order_id=$request->input('id');
                $admin_id = $request->session()->get('uid');
                $sql=DB::table('detail')->where('order_id',$order_id)->get();
                //var_dump($sql);die;
                $where=[
                    'admin_id'=>$admin_id,
                    'post_code'=>1
                ];

                $ord=DB::table('address')->where($where)->get();
                return view("index.payment")->with(['sql'=>$sql])->with(['ord'=>$ord]);


            }
    //第二次进入 结算页面
        public function pays(Request $request){
            $order_id=$request->input('order_id');

            $admin_id = $request->session()->get('uid');
            $sql=DB::table('detail')->where('order_id',$order_id)->get();

            $where=[
                'admin_id'=>$admin_id,
                'post_code'=>1
            ];

            $ord=DB::table('address')->where($where)->get();
            return view("index.payment")->with(['sql'=>$sql])->with(['ord'=>$ord]);

        }
//地址 展示页面

    public  function address(Request $request){
        $admin_id=$request->session()->get('uid');
        $where=[
            'admin_id'=>$admin_id,
            'status_add'=>0
        ];
        $address=DB::table('address')->where($where)->get();

        return view('index.address')->with(['address'=>$address]);
    }

    //地址管理  点击默认 功能
    public function adds(Request $request){
        $id=$request->input('id');
        $order_id=$request->input('id');
        $admin_id = $request->session()->get('uid');
        //var_dump($admin_id);die;
        $where=[
            'admin_id'=>$admin_id,
            'post_code'=>1
        ];
        $data=[
            'post_code'=>0
        ];
        DB::table('address')->where($where)->update($data);

        $datas=[
            'post_code'=>1
        ];
        $asdssa=DB::table('address')->where('id',$id)->update($datas);

        if($asdssa){
            $asdssa=array(
                'status'=>3,
                'order_id'=>$order_id
            );
            return $asdssa;
        }

    }

    //地址 删除
    public function deles(Request $request){
        $id=$request->input('id');
        $data=[
            'status_add'=>1
        ];
        $delesss=DB::table('address')->where('id',$id)->update($data);
        if($delesss){
            $delesss=array(
                'status'=>1
            );
            return $delesss;
        }
    }
//    //地址修改
//    public function upda(Request $request){
//        $id=$request->input('id');
//        $up=DB::table('address')->where('id',$id)->get();
//        return view('index.writeaddr');
//    }
    //购物车删除 单删除
    public function delete(Request $request){
        //echo 123;die;
        $cart_id=$request->input('cart_id');
        //var_dump($cart_id);die;
        $arr=[
            'is_show'=>1
        ];
        $data=DB::table('carts')->where('goods_id',$cart_id)->update($arr);
        //var_dump($data);die;
        if($data){
            $data=array(
                'status'=>0,
                'msg'=>'删除成功'
            );
            return $data;
        }
    }
    //全选 删除
    public function delss(Request $request){
        $post=$request->input('arr');

        $data=[
            'is_show'=>1
        ];
        $opp=DB::table('carts')->whereIn('goods_id',$post)->update($data);
        if($opp){
            $mz=array(
                "status"=>2,

            );
            return $mz;
        }
    }


    public function shopcontent(Request $request){
        $nums=DB::table('carts')->pluck('num')->toArray();
        $array_num=array_sum($nums);
        $post=$request->input('id');
        $arr=Goods::where('goods_id',$post)->first();
        //print_r($arr);die;

         return view('index.shopcontent')->with(['arr'=>$arr])->with(['array_num'=>$array_num]);
    }

//购物车
    public function carts(Request $request){
        $admin_id=$request->session()->get('uid');
        //var_dump($admin_id);die;
        $where=[
            'is_show'=>0,
            'admin_id'=>$admin_id
        ];
        $data=DB::table('carts')
            ->join('goods','carts.goods_id','=','goods.goods_id')
            ->where($where)->get();
             //var_dump($data);die;
        $apps=DB::table('carts')
            ->join('goods','carts.goods_id','=','goods.goods_id')
            ->where('goods.cat_show',1)->get();
        return view('index.shopcart')->with(['data'=>$data])->with(['apps'=>$apps]);
    }
//商品文本框
    public function end(Request $request){
        $num=$request->input();
        $t=$num['t'];
        $goods_id=$num['ad'];
        //var_dump($goods_id);die;
        $da=[
            'num'=>$t
        ];
        $pot=DB::table('carts')->where('goods_id',$goods_id)->update($da);
        //print_r($pot);die;

    }
    //商品加号
    public function jia(Request $request){
        $post=$request->input();
        $apa=DB::table('carts')->where('goods_id',$post['ad'])->first();
        $acs=$apa->num;
        //var_dump($acs);die;
        $data=[
            'num'=>$acs+1
        ];
        $pot=DB::table('carts')->where('goods_id',$post['ad'])->update($data);
    }
    //商品减号
    public function jian(Request $request){
        $post=$request->input();
        if($post['aa']<2){
            die;
        }
        $apa=DB::table('carts')->where('goods_id',$post['ad'])->first();
        $acs=$apa->num;
        $data=[
            'num'=>$acs-1
        ];
        $pot=DB::table('carts')->where('goods_id',$post['ad'])->update($data);
    }

    public function app(Request $request){
        $sess=$request->session()->get('name');
        if($sess){
            $pp=array(
                "status"=>0
            );
            return $pp;
        }else{
            $oo=array(
                "status"=>1
            );
            return $oo;
        }


    }

   // 全部商品的分类展示数据
    public function allshops(Request $request){
        $cate_id=$request->input('cate_id');
        $arr=Goods::where("is_on_sale",1);
        if($cate_id!=0){
            $arr = $arr->where('cate_id',$cate_id);
        }
        $arr = $arr->get();
        $view=view('denglu.allshoplist',['data'=>$arr]);
        $data['view']=response($view)->getContent();
        return $data;
    }
//流加载  全部商品页面
    public function show(Request $request){
          $arr = array();
            $page = $request->input('page',1);
            $pageNum=6;
            $offset=($page-1)*$pageNum;

            $arrDaataInfo=DB::table('goods')->offset($offset)->limit($page,$pageNum)->get();
            $totalData=DB::table('goods')->count();
            //总条数
            $pageTotal=ceil($totalData/$pageNum);
            $objview=view('denglu.alllist',['arrDaataInfo'=>$arrDaataInfo]);
            $content=response($objview)->getContent();
            $arr['info']=$content;
            $arr['page']=$pageTotal;
            return $arr;

    }

    //收货地址
    public function writeaddr(Request $request){
        $id=$request->input('id');
        return view('index.writeaddr');
    }
    public function writeaddrss(Request $request){
        $id=$request->input('id');
        $upda=DB::table('address')->where('id',$id)->first();
        return view('index.writeaddrss')->with(['upda'=>$upda]);
    }

    //修改的 执行方法
    public function updayy(Request $request){
        $admin_id = $request->session()->get('uid');
        $id=$request->input('id');
        $name=$request->input('name');
        $phone=$request->input('phone');
        $address=$request->input('address');
        $check=$request->input('check');
        if($check==1){
            $a=[
                'post_code'=>0
            ];
            DB::table('address')->where('admin_id',$admin_id)->update($a);
        }
        $where=[
            'id'=>$id
        ];
        $time=time();
        $data=[
            'order_receive_name'=>$name,
            'receive_phone'=>$phone,
            'receive_address'=>$address,
            'post_code'=>$check,
            'ctime'=>$time
        ];
        $lkj=DB::table('address')->where($where)->update($data);
        if($lkj){
            $lkj=array(
                'status'=>0
            );
            return $lkj;
        }
    }
    //收货地址添加  入 表
    public  function wri(Request $request){
        $admin_id = $request->session()->get('uid');
        $order_id = $request->session()->get('order_id');
        $name=$request->input('name');
        $phone=$request->input('phone');
        $address=$request->input('address');
        $check=$request->input('check');
        $where=[
            'admin_id'=>$admin_id,
            'post_code'=>1
        ];
        if($check==1){
            $where=[
                'admin_id'=>$admin_id,
                'post_code'=>1
            ];
            $data=[
                'post_code'=>0
            ];
            DB::table('address')->where($where)->update($data);
        }
        $time=time();
        $data=[
            'order_id'=>$order_id,
            'admin_id'=>$admin_id,
            'order_receive_name'=>$name,
            'receive_phone'=>$phone,
            'receive_address'=>$address,
            'post_code'=>$check,
            'ctime'=>$time,
        ];
        $desc=DB::table('address')->insert($data);
        if($desc){
            $msg=array(
                'status'=>0,
                'order_id'=>$order_id
            );
            return $msg;
        }
    }

    // 支付 页面
    public function mone(Request $request){
        $content=$request->input('content');
        //var_dump($content);die;
        if($content){
            echo 123;
        }else{
            $zh=array(
                'status'=>0
            );
            return $zh;
        }
    }

    //我的潮购
    public function userprop(Request $request){
        $admin_id=$request->session()->get('uid');
        $arr=DB::table('order')
            ->join('detail','order.order_id','=','detail.order_id')
            ->where('order.admin_id',$admin_id)
            ->get();
        //var_dump($arr);die;
        return view('index.userprop')->with(['arr'=>$arr]);
    }

//    人气
//    public  function shop_price(){
//        $arr=DB::table('goods')->select('shop_price')->orderBy('shop_price',"desc")->get();
//        $view=view('denglu.allshoplist',['data'=>$arr]);
//        $data['view']=response($view)->getContent();
//        return $data;
//
//    }



}
