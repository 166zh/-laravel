<?php

namespace App\Http\Controllers\huan;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class Add extends Controller
{
    public function order(Request $request){
    	$url = url('show');
    	return redirect($url);
    }
    public function add(){
    	$sql="select * from user";
    	$arr = DB::select($sql);
    	print_r($arr);

    }
    public function le(){
    	$sql = "insert into user set name='qqq',age='20'";
    	$arr = DB::insert($sql);

    }
    public function delete(){
    	$sql = "delete from user where id='2'";
    	DB::delete($sql);
    }
    public function up(){
    	$sql = "update user set name='zhanghuan',age='20' where id='1'";
    	DB::update($sql);
    }
}

