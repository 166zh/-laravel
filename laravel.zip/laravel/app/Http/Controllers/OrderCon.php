<?php

namespace App\Http\Controllers;

use app\Http\Controllers;

class OrderCon extends Controller
{
    public function show(){
    	echo 'dasugfuyw';
    }
}
