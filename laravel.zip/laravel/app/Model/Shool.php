<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Shool extends Model
{

    protected $table="shool";

    public $timestamps=false;
}
