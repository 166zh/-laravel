<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Detail extends Model
{
    protected $table="detail";
}
