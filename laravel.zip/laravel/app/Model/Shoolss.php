<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Shoolss extends Model
{

    protected $table="shoolss";

    public $timestamps=false;
}
