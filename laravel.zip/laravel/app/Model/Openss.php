<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Openss extends Model
{
    protected $table="openss";
}
