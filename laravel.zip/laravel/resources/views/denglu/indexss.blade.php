@foreach($arrDaataInfo as $ke=>$va)
    <li id="23558" codeid="12751965" goodsid="23558" codeperiod="28436">
        <a href="javascript:;" class="g-pic">
            <a href="/shopcontent"><img class="lazy" name="goodsImg"  width="136" height="136" src="{{URL::asset('uploads/'.$va->goods_img)}}"></a>
        </a>
        <p class="g-name">(第<em>28436</em>潮){{$va->goods_name}}</p>
        <ins class="gray9">价值：￥{{$va->market_price}}</ins>
        <div class="layui-progress">
            <div class="layui-progress-bar" lay-percent="10%"></div>
        </div>

        {{--<div class="btn-wrap" name="buyBox" limitbuy="0" surplus="58" totalnum="1625" alreadybuy="1567">--}}
            {{--<a href="javascript:;" class="buy-btn" codeid="12751965">立即潮购</a>--}}
            {{--<div class="gRate" codeid="12751965" canbuy="58">--}}
                {{--<a href="javascript:;"></a>--}}
            {{--</div>--}}
        {{--</div>--}}
    </li>
@endforeach

<script>
    //注意进度条依赖 element 模块，否则无法进行正常渲染和功能性操作
    layui.use('element', function(){
        var element = layui.element;
    });
</script>