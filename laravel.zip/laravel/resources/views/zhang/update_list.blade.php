
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
    </head>
    <script src="/js/jquery.js"></script>
    <body>
		<form id="xiu">

			<input type="hidden" name="a_id" value="{{$goodsdata[0]->a_id}}">
			名称：<input type="text" name="a_name" value="{{$goodsdata[0]->a_name}}"><br />
			分类：<select name="b_id">
					@foreach($categorydata as $v)
				@if($v->b_id==$goodsdata[0]->b_id)
					<option value="{{$v->b_id}}" selected>{{$v->b_name}}</option>
				@else
					<option value="{{$v->b_id}}">{{$v->b_name}}</option>
				@endif
					@endforeach
				</select><br />
			描述：<textarea name="a_value" id="" cols="30" rows="10">{{$goodsdata[0]->a_value}}</textarea><br/>
			是否热销：
			@if($goodsdata[0]->a_hot==1)
				<input type="radio" name="a_hot" checked value="1">是<input type="radio" name="a_hot" value="0">否<br />
			@else
				<input type="radio" name="a_hot" value="1">是<input type="radio" name="a_hot" checked value="0">否<br />
			@endif
			是否上架：
			@if($goodsdata[0]->a_show==1)
				<input type="radio" name="a_show" checked value="1">是<input type="radio" name="a_show" value="0">否<br />
			@else
				<input type="radio" name="a_show" value="1">是<input type="radio" name="a_show" checked value="0">否<br />
			@endif
			<input type="button" id="butt" value="修改">
		</form>
    </body>
</html>
<script>
	$('#butt').click(function(){
		var data = $('#xiu').serialize();
		$.ajax({
			url: '/update',
			type: 'POST',
			data: data,
		}).done(function(data) {
			if(data==1){
				alert("修改成功");
				window.location.href="/is";
			}else{
				alert("修改失败");
			}
		})
	})
</script>