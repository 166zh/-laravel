<table border=1  id="wo">

    <tr>
        <td>id</td>
        <td>名称</td>
        <td>分类</td>
        <td>描述</td>
        <td>是否热销</td>
        <td>是否上架</td>
        <td>操作</td>
    </tr>
    @foreach($arr as $k=>$v)
        <tr idval="{{$v->a_id}}">
            <td>{{$v->a_id}}</td>
            <td><span class="a_name">{{$v->a_name}}</span></td>
            <td>{{$v->b_name}}</td>
            <td>{{$v->a_value}}</td>

            <td><?php if($v->a_hot==0){echo '是';}else{echo '否';}?></td>

            <td><?php if($v->a_show==0){echo '是';}else{echo '否';}?></td>
            <td><a href="javascript:;" onclick="del({{$v->a_id}})">删除</a>
                <a href="etix/{{$v->a_id}}">修改</a>
            </td>
        </tr>
    @endforeach
</table>