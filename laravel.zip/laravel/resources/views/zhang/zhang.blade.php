
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<script src="/js/jquery.js"></script>
</head>
<body>
	<form action="" id="form">
		<table border='1'>
			<tr>
				<td>名称：</td>
				<td><input type="text"  id="a_name" name='a_name'></td>
			</tr>
			<tr>
				<td>分类：</td>
				<td><select name="b_id" id="b_id">
					@foreach($arr as $v)
					<option value="{{$v->b_id}}">{{$v->b_name}}</option>
					@endforeach
				</select></td>
			</tr>
			<tr>
				<td>描述：</td>
				<td><textarea name="a_value" id="a_value" cols="30" rows="10"></textarea></td>
			</tr>
			<tr>
				<td>是否热销：</td>
				<td><input type="radio" name="a_hot"  value='0'>是
					<input type="radio" name="a_hot"  value='1'>否
				</td>
			</tr>
			<tr>
				<td>是否上架：</td>
				<td>
					<input type="radio" name="a_show"  value='0'>是
					<input type="radio" name="a_show"  value='1'>否
				</td>
			</tr>
			<tr>
				<td><input type="button" id="butt"  value="提交"></td>
				<td></td>
			</tr>
		</table>
	</form>
</body>
</html>
<script>
	$('#butt').click(function(){
		var data = $('#form').serialize();
		$.ajax({
			url: 'inser',
			type: 'POST',
			data: data,
		}).done(function(data) {
			if(data){
				alert('添加成功');
				window.location.href="is";
			}
		});
	});

    
</script>