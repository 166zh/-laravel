<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>购物车</title>
    <meta content="app-id=518966501" name="apple-itunes-app" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0" />
    <meta content="yes" name="apple-mobile-web-app-capable" />
    <meta content="black" name="apple-mobile-web-app-status-bar-style" />
    <meta content="telephone=no" name="format-detection" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <link href="css/comm.css" rel="stylesheet" type="text/css" />
    <link href="css/cartlist.css" rel="stylesheet" type="text/css" />
    <script src="js/jquery-1.11.2.min.js"></script>
    <script src="http://cdn.bootcss.com/flexslider/2.6.2/jquery.flexslider.min.js"></script>
    <script src="js/swiper.min.js"></script>
    <script src="js/photo.js" charset="utf-8"></script>
    <script src="layui/layui.js"></script>
    <link rel="stylesheet" href="layui/css/layui.css">
</head>
<body id="loadingPicBlock" class="g-acc-bg">
<input name="hidUserID" type="hidden" id="hidUserID" value="-1" />
<div>
    <!--首页头部-->
    <div class="m-block-header">
        <a href="/" class="m-public-icon m-1yyg-icon"></a>
        <a href="/" class="m-index-icon">编辑</a>
    </div>
    <!--首页头部 end-->
    <div class="g-Cart-list">
        @if($data)
        <ul id="cartBody">

            @foreach($data as $key=>$values)
            <li price="{{$values->shop_price}}" goods_num="{{$values->goods_number}}">

                <s class="xuan " cartid="{{$values->goods_id}}"></s>
                <a class="fl u-Cart-img" href="/v44/product/12501977.do">
                    <img class="imsges" src="{{URL::asset('uploads/'.$values->goods_img)}}" border="0" alt="">
                </a>
                <div class="u-Cart-r">
                    <a href="/v44/product/12501977.do" name="{{$values->goods_name}}" class="gray6">(已更新至第{{$values->goods_id}}潮){{$values->goods_name}}（AZ_Emperor）【单价 ￥{{$values->shop_price}}】</a>
                        <span class="gray9">
                            <em>剩余124人次</em>
                        </span>
                    <div class="num-opt">
                        <em class="num-mius dis min" cartid="{{$values->goods_id}}" ad="{{$values->goods_id}}"><i></i></em>
                        <input class="text_box" name="num" ad="{{$values->goods_id}}" maxlength="6" type="text" value="{{$values->num}}" codeid="12501977">
                        <em name="end" ad="{{$values->goods_id}}" cartid="{{$values->goods_id}}" class="num-add add"><i></i></em>
                    </div>
                    <a href="javascript:;"  name="delLink" aa="{{$values->goods_id}}" cartid="{{$values->goods_id}}" cid="12501977" isover="0" class="z-del"><s></s></a>
                </div>
            </li>
          @endforeach

        </ul>
        @else
        <div id="divNone" class="empty "  style="display: none"><s></s><p>您的购物车还是空的哦~</p><a href="https://m.1yyg.com" class="orangeBtn">立即潮购</a></div>
            @endif
    </div>

    <div id="mycartpay" class="g-Total-bt g-car-new" style="">
        <dl>
            <dt class="gray6">
                <s class="quanxuan"></s>全选
            <p class="money-total">合计<em class="orange total"><span>￥</span>0</em></p>

            </dt>
            <dd>
                <a href="javascript:;" name="app" id="a_payment" class="orangeBtn w_account remove">删除</a>

                <a href="javascript:;" name="add" id="a_payment" class="orangeBtn w_account post">去结算</a>
            </dd>
        </dl>
    </div>

    <script>
        //结算 购物车
        $('.post').click(function(){
            var data=[];
            $(".g-Cart-list .xuan").each(function () {
                if ($(this).hasClass("current")) {
                    data.push($(this).attr('cartid'));

                }
            });

            //获取图片路径
            var img=$('.imsges').prop('src');
            //名称
            var goods_name=$(".gray6").attr('name');

            var input=$('.text_box').val();
            //alert(input);
            var url="/payment";

            $.ajax({
                type:"post",
                data:{data:data,input:input,img:img,goods_name:goods_name},
                url:url,
                dataType:"json",
                success:function(msg){
                    if(msg.status==1){
                        alert("请先登录");
                        window.location.href="/login";
                    }
                    if(msg.status==2){
                        alert('未选中商品 不可提交');
                    }

                    if(msg.status==3){
                        //alert(msg.order_id);
                        alert('提交成功');
                        window.location.href="/pay?id="+msg.order_id;

                    }

                }
            })

        })

        //批量删除
        $(".remove").click(function(){
            var arr=[];
            $(".g-Cart-list .xuan").each(function () {
                if ($(this).hasClass("current")) {
                    arr.push($(this).attr('cartid'));

                }
            });

            var url="/delss";

            $.ajax({
                type:"post",
                data:{arr:arr},
                url:url,
                dataType:"json",
                success:function(msg){
                    if(msg.status==2){
                        alert('删除成功');
                        window.location.reload();
                    }
                }
            })

        })
        //单删除
        $("[name='delLink']").click(function(){
            var layer=layui.layer;
            var obj=$(this);
            var cart_id=obj.attr('aa');

            var data={};
            var url="/delete";
            data.cart_id=cart_id;
            $.ajax({
                type:"post",
                data:data,
                url:url,
                dataType:"json",
                success:function(msg){
                    if(msg.status==0){
                        alert('删除成功');
                        window.location.href="/carts";
                    }
                }
            })
        })
    </script>
    <div class="hot-recom">
        <div class="title thin-bor-top gray6">
            <span><b class="z-set"></b>人气推荐</span>
            <em></em>
        </div>
        <div class="goods-wrap thin-bor-top">
            <ul class="goods-list clearfix">
                @foreach($apps as $ki=>$vol)
                <li>
                    <a href="https://m.1yyg.com/v44/products/23458.do" class="g-pic">
                        <img src="{{URL::asset('uploads/'.$vol->goods_img)}}" width="136" height="136">
                    </a>
                    <p class="g-name">
                        <a href="https://m.1yyg.com/v44/products/23458.do">(第<i>{{$vol->goods_id}}</i>潮){{$vol->goods_name}}（Apple）欢总万岁</a>
                    </p>
                    <ins class="gray9">价值:￥{{$vol->shop_price}}</ins>
                    <div class="btn-wrap">
                        <div class="Progress-bar">
                            <p class="u-progress">
                                    <span class="pgbar" style="width:1%;">
                                        <span class="pging"></span>
                                    </span>
                            </p>
                        </div>
                        <div class="gRate" data-productid="23458">
                            <a href="javascript:;"><s></s></a>
                        </div>
                    </div>
                </li>
                @endforeach


            </ul>
        </div>
    </div>




    <div class="footer clearfix">
        <ul>
            <li class="f_home"><a href="/v41/index.do" ><i></i>潮购</a></li>
            <li class="f_announced"><a href="/v41/lottery/" ><i></i>最新揭晓</a></li>
            <li class="f_single"><a href="/v41/post/index.do" ><i></i>晒单</a></li>
            <li class="f_car"><a id="btnCart" href="/v41/mycart/index.do" class="hover"><i></i>购物车</a></li>
            <li class="f_personal"><a href="/v41/member/index.do" ><i></i>我的潮购</a></li>
        </ul>
    </div>

    <script src="js/jquery-1.11.2.min.js"></script>
    <!---商品加减算总数---->
    <script type="text/javascript">
        //加号
        $(function () {
            $(".add").click(function () {
                var t = $(this).prev();
                t.val(parseInt(t.val()) + 1);
                GetCount();


                var aa=$(this).prev().attr('value');

                var ad=$(this).attr('ad');
                var data={};
                data.aa=aa;
                data.ad=ad;
                var url="/jia";
                $.ajax({
                    type:"post",
                    url:url,
                    data:data,
                    dataType:"json",
                    success:function(msg){

                    }
                })
            })

        })
        //文本框 失焦事件
        $(function () {
            $(".text_box").blur(function () {

                //alert(465);
                //文本框的值
                var t = $(this).val();
                if(t<1){
                    t.val(1);
                    t=1;
                }
               // alert(t);
                //当前id
                var ad=$(this).attr('ad');
                var cartBody=$('#cartBody li').attr('goods_num');

                var t=parseInt(t);

                if(t > cartBody){
                    alert('添加商品数量超过库存');
                }else{

                    var data={};
                    data.t=t;
                    data.ad=ad;
                    var url="/end";
                    $.ajax({
                        type:"post",
                        url:url,
                        data:data,
                        dataType:"json",
                        success:function(msg){
                            window.location.href="/carts";
                        }
                    })
                }


            })
            $(".min").click(function () {
                var t = $(this).next();
                if(t.val()>1){
                    t.val(parseInt(t.val()) - 1);
                    GetCount();
                }

                //文本框的值
                var aa=$(this).next().attr('value');
                if(aa<1){
                    t.val(1);
                    aa=1;
                }
                //当前id
                var ad=$(this).attr('ad');

                var data={};
                data.aa=aa;
                data.ad=ad;
                var url="/jian";
                $.ajax({
                    type:"post",
                    url:url,
                    data:data,
                    dataType:"json",
                    success:function(msg){
                        window.location.href="/carts";
                    }
                })

            })
        })
    </script>




    <script>

        // 全选
        $(".quanxuan").click(function () {
            if($(this).hasClass('current')){
                $(this).removeClass('current');

                $(".g-Cart-list .xuan").each(function () {
                    if ($(this).hasClass("current")) {
                        $(this).removeClass("current");
                    } else {
                        $(this).addClass("current");
                    }
                });
                GetCount();
            }else{
                $(this).addClass('current');

                $(".g-Cart-list .xuan").each(function () {
                    $(this).addClass("current");
                    // $(this).next().css({ "background-color": "#3366cc", "color": "#ffffff" });
                });
                GetCount();
            }


        });
        // 单选
        $(".g-Cart-list .xuan").click(function () {
            if($(this).hasClass('current')){


                $(this).removeClass('current');

            }else{
                $(this).addClass('current');
            }
            if($('.g-Cart-list .xuan.current').length==$('#cartBody li').length){
                $('.quanxuan').addClass('current');

            }else{
                $('.quanxuan').removeClass('current');
            }
            // $("#total2").html() = GetCount($(this));
            GetCount();
            //alert(conts);
        });
        // 已选中的总额
        function GetCount() {
            var conts = 0;
            var aa = 0;
            $(".g-Cart-list .xuan").each(function () {
                if ($(this).hasClass("current")) {
                    for (var i = 0; i < $(this).length; i++) {
                        conts += parseInt($(this).parents('li').find('input.text_box').val()) * $(this).parents('li').attr("price");
                        // aa += 1;
                    }
                }
            });

            $(".total").html('<span>￥</span>'+(conts).toFixed(2));

        }
        GetCount();

    </script>
</body>
</html>
