<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('hello', function () {

	 return 'Hello, Welcome to LaravelAcademy.org';

	});
 
Route::get('hello', function () {
	return 'Hello, Welcome to LaravelAcademy.org';
});

Route::get("show","OrderCon@show");

Route::get("show","Goods@show");



Route::get("a","huan\Add@order");
//路由前缀
Route::prefix('huan')->group(function(){
	Route::get("add","order\Goods@show");
	Route::get('show',function(){
		echo 222;
	});
});

//路由接参数 跳转 

Route::get('show/{id}',function($id){
	if($id < 5){
		return redirect("http://www.baidu.com");
	}
});

Route::get("b","huan\Add@up");

Route::get("add","order\Goods@show");

Route::any("inser","order\Goods@inser");

Route::any("is","order\Goods@is");

Route::any("delet","order\Goods@delet");

Route::any("exita","order\Goods@exita");

Route::any("test","order\Goods@test");

Route::any("fie","order\Goods@upName");

Route::any("etix/{id}","order\Goods@etix");

Route::any("update","order\Goods@update");

Route::any("tion","order\Goods@tion");

Route::get("info","Auth\LianxiController@info");

Route::get("go","Auth\LianxiController@go")->middleware("test");

Route::any("login","Auth\LianxiController@login");

Route::any("register","Auth\LianxiController@register");

Route::any("add","Auth\LianxiController@add");

Route::any("login_add","Auth\LianxiController@login_add");

Route::any("index","Auth\LianxiController@index");

Route::any("t1","Auth\LianxiController@t1");

Route::any("allshop","index\AllShop@allshop");

Route::any("opens","Auth\LianxiController@opens");

Route::any("stode","Auth\LianxiController@stode");

Route::any("allshops","index\AllShop@allshops");

Route::any("goodslist","Auth\LianxiController@goodslist");

Route::any("show","index\AllShop@show");

Route::any("userpage","index\AllShop@userpage");
Route::any("shopcart","index\AllShop@shopcart");
Route::any("carts","index\AllShop@carts");
Route::any("delete","index\AllShop@delete");
Route::any("end","index\AllShop@end");
Route::any("jia","index\AllShop@jia");
Route::any("jian","index\AllShop@jian");
Route::any("payment","index\AllShop@payment");
Route::any("delss","index\AllShop@delss");
Route::any("app","index\AllShop@app");
Route::any("shopcontent","index\AllShop@shopcontent");
Route::any("pay","index\AllShop@pay");
Route::any("writeaddr","index\AllShop@writeaddr");         //收货地址添加
Route::any("wri","index\AllShop@wri");
Route::any("pays","index\AllShop@pays");
Route::any("address","index\AllShop@address");
Route::any("info","index\AllShop@info");
Route::any("mone","index\AllShop@mone");
Route::any("upda","index\AllShop@upda");
Route::any("adds","index\AllShop@adds");
Route::any("deles","index\AllShop@deles");
Route::any("updayy","index\AllShop@updayy");
Route::any("userprop","index\AllShop@userprop");//我的潮购
Route::any("writeaddrss","index\AllShop@writeaddrss");//修改的页面
//Route::any("shop_price","index\AllShop@shop_price");