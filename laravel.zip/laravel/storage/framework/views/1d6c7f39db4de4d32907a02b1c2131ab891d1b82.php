<?php $__currentLoopData = $arrDaataInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ke=>$va): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li id="23558" codeid="12751965" goodsid="23558" codeperiod="28436">
        <a href="javascript:;" class="g-pic">
            <a href="/shopcontent"><img class="lazy" name="goodsImg"  width="136" height="136" src="<?php echo e(URL::asset('uploads/'.$va->goods_img)); ?>"></a>
        </a>
        <p class="g-name">(第<em>28436</em>潮)<?php echo e($va->goods_name); ?></p>
        <ins class="gray9">价值：￥<?php echo e($va->market_price); ?></ins>
        <div class="layui-progress">
            <div class="layui-progress-bar" lay-percent="10%"></div>
        </div>

        
            
            
                
            
        
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    //注意进度条依赖 element 模块，否则无法进行正常渲染和功能性操作
    layui.use('element', function(){
        var element = layui.element;
    });
</script>