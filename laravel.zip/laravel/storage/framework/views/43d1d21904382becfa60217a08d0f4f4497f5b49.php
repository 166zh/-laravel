<table border=1  id="wo">

    <tr>
        <td>id</td>
        <td>名称</td>
        <td>分类</td>
        <td>描述</td>
        <td>是否热销</td>
        <td>是否上架</td>
        <td>操作</td>
    </tr>
    <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr idval="<?php echo e($v->a_id); ?>">
            <td><?php echo e($v->a_id); ?></td>
            <td><span class="a_name"><?php echo e($v->a_name); ?></span></td>
            <td><?php echo e($v->b_name); ?></td>
            <td><?php echo e($v->a_value); ?></td>

            <td><?php if($v->a_hot==0){echo '是';}else{echo '否';}?></td>

            <td><?php if($v->a_show==0){echo '是';}else{echo '否';}?></td>
            <td><a href="javascript:;" onclick="del(<?php echo e($v->a_id); ?>)">删除</a>
                <a href="etix/<?php echo e($v->a_id); ?>">修改</a>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>