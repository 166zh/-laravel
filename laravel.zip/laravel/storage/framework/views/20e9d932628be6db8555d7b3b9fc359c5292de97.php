
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
    </head>
    <script src="/js/jquery.js"></script>
    <body>
		<form id="xiu">

			<input type="hidden" name="a_id" value="<?php echo e($goodsdata[0]->a_id); ?>">
			名称：<input type="text" name="a_name" value="<?php echo e($goodsdata[0]->a_name); ?>"><br />
			分类：<select name="b_id">
					<?php $__currentLoopData = $categorydata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($v->b_id==$goodsdata[0]->b_id): ?>
					<option value="<?php echo e($v->b_id); ?>" selected><?php echo e($v->b_name); ?></option>
				<?php else: ?>
					<option value="<?php echo e($v->b_id); ?>"><?php echo e($v->b_name); ?></option>
				<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select><br />
			描述：<textarea name="a_value" id="" cols="30" rows="10"><?php echo e($goodsdata[0]->a_value); ?></textarea><br/>
			是否热销：
			<?php if($goodsdata[0]->a_hot==1): ?>
				<input type="radio" name="a_hot" checked value="1">是<input type="radio" name="a_hot" value="0">否<br />
			<?php else: ?>
				<input type="radio" name="a_hot" value="1">是<input type="radio" name="a_hot" checked value="0">否<br />
			<?php endif; ?>
			是否上架：
			<?php if($goodsdata[0]->a_show==1): ?>
				<input type="radio" name="a_show" checked value="1">是<input type="radio" name="a_show" value="0">否<br />
			<?php else: ?>
				<input type="radio" name="a_show" value="1">是<input type="radio" name="a_show" checked value="0">否<br />
			<?php endif; ?>
			<input type="button" id="butt" value="修改">
		</form>
    </body>
</html>
<script>
	$('#butt').click(function(){
		var data = $('#xiu').serialize();
		$.ajax({
			url: '/update',
			type: 'POST',
			data: data,
		}).done(function(data) {
			if(data==1){
				alert("修改成功");
				window.location.href="/is";
			}else{
				alert("修改失败");
			}
		})
	})
</script>