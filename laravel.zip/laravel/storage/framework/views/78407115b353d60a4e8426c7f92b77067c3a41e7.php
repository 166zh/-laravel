<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<script src="/js/jquery.js"></script>
	<style>
		.pagination li{float: left;margin-left: 20px;list-style: none;}
</style>
</head>
<body>

	<span>是否热卖：</span>
		<select name="a_hot" id="hot">
			<option value="0">是</option>	
			<option value="1">否</option>	
		</select>

	<span>是否上架：</span>
		<select name="a_show" id="show">
			<option value="0">是</option>	
			<option value="1">否</option>	
		</select>

	<input type="submit" id="suo" value="搜索">


	<table border=1  id="wo">

		<tr>
			<td>id</td>
			<td>名称</td>
			<td>分类</td>
			<td>描述</td>
			<td>是否热销</td>
			<td>是否上架</td>
			<td>操作</td>
		</tr>
		<?php $__currentLoopData = $sql; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr idval="<?php echo e($v->a_id); ?>">
			<td><?php echo e($v->a_id); ?></td>
			<td><span class="a_name"><?php echo e($v->a_name); ?></span></td>
			<td><?php echo e($v->b_name); ?></td>
			<td><?php echo e($v->a_value); ?></td>
	
			<td><?php if($v->a_hot==0){echo '是';}else{echo '否';}?></td>
	
			<td><?php if($v->a_show==0){echo '是';}else{echo '否';}?></td>
			<td><a href="javascript:;" onclick="del(<?php echo e($v->a_id); ?>)">删除</a>
				<a href="etix/<?php echo e($v->a_id); ?>">修改</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<?php echo e($sql->links()); ?>

</body>
</html>
<script>
	$('#suo').click(function(){
		var  hot=$('#hot').val();
		var  show=$('#show').val();
		$.ajax({
			type:"POST",
			url:"/tion",
			data:{hot:hot,show:show},
		}).done(function(msg){
			$('#wo').html(msg);
		})

	});
</script>
<script>
	function del(id){

    if(confirm("您确定要删除该条信息么?")){
      $.ajax({
        type: "POST",
        url: "delet",
        data: {id: id }
      }).done(function( msg ) {
        if(msg==1){
        	alert('删除成功');
        }
      });
     //window.location.reload();
    }

  }
  function update_data(id){

	 $.ajax({
        type: "POST",
        url: "exita",
        data: {id: id }
      }).done(function( msg ) {
        	if(msg){
        		window.location.href="exita";
        	}
      });
     //window.location.reload();
    

  }
  //极点技改
   
   $(document).on("click",".a_name",function(){
   		var a_name=$(this).text();//span标签用text()获取值
   		//alert(a_name);
   		
   		//把文本换成input框
    	$(this).parent().html("<input type='text' name='a_name' value="+a_name+">");
   })
   $(document).on("blur","[name='a_name']",function(){  

    // 获取修改后的值
    var field = $(this).val();
     //alert(field);
    // 判断非空
    if(field == ''){
        alert('名称不能为空');
        return ;
    }
	// 获取所属数据主键Id
    var id=$(this).parent().parent().attr('idval');
    //alert(id);
     // 将input转换为span,并将要修改值赋给span标签
    $(this).parent().html("<span class='a_name'>"+field+"</span>");

    $.ajax({
    	method:"POST",
    	url:"fie",
    	data:{a_name:field,id:id},
    	dataType:'json'
    }).done(function( msg ){
    	//console.log(msg);
    	alert(msg.msg);
    });
})

</script>